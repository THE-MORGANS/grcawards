<!DOCTYPE html>
<html lang="en">
<?php $__env->startSection('title', 'Judges'); ?>

<head>
    <?php echo $__env->make('partials.voter.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="<?php echo e(asset('assets/css/model-new.css')); ?>" rel="stylesheet" />
</head>

<body id="conference-page">
    <!-- =============== PRELOADER =============== -->
    <div class="page-preloader-cover">
        <div class="cssload-loader">
            <div class="cssload-inner">
                <img class="ball" src="https://res.cloudinary.com/the-morgans-consortium/image/upload/v1664067165/grcfincrimeawards/landing_page/grc_awards_summit_logo_y8nqdz.png" />
            </div>
        </div>

    </div>
    <!-- ============== PRELOADER END ============== -->
    <!-- ================= HEADER ================= -->
    <?php echo $__env->make('partials.voter.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =============== HEADER END =============== -->
    <!-- Page title -->
    <div class="page-title" style="background-color:#D4AF37">
        <div class="container">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?php echo e(route('landing.index')); ?>">Home</a></li>
                    <li>Judges</li>
                </ul>
            </div>
            <h3 class="title">Our Judges</h3>
        </div>
    </div>
    <!-- page title -->

    <section class="s-news s-single-news" style="background-color: #fff;">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8 blog-cover">
                    <div class="post-item-cover">
                        <div class="widget widget-archive post-header">
                            <h4 class="title">Meet Our Judges</h4>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $judges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="slide-our-speaker">
                                <div class="our-speaker-item">
                                    <a href="" data-bs-toggle="modal" data-bs-target="#j<?php echo e($judge->hashid); ?>">
                                    <img src="<?php echo e($judge->path_to_image); ?>" alt="img" style="height: 360px;">
                                    <div class="speaker-item-info" style="padding-bottom:10px;">
                                            <h5 class="name" style="font-size:18px"><?php echo e($judge->name); ?></h5>
                                            <p class="prof" style="font-size:16px; color:white"><?php echo e($judge->position); ?></p>
                                            <div class="meta">
                                                <?php if($judge->ln_link != ''): ?>
                                                <span class="post-tag" style="margin-right:7px;">
                                                    <a href="<?php echo e($judge->ln_link); ?>">
                                                        <i class="mdi mdi-linkedin mdi-24px" style="color:#fff" aria-hidden="true"></i>
                                                    </a>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="post-item-cover">

						<div class="widget widget-archive post-header">
							<h4 class="title">Selection of panel of judges</h4>
						</div>
						<div class="post-content">
							<div class="text" style="text-align: justify;">
							<p>The awards are judged by an independent panel of judges who are representative of all areas of the industry by sector and by geography. Members of this panel choose to contribute on a voluntary basis and will remain entirely separate from the ownership structure of the awards.</p>
                            <p>The panel is led by Mr Adebisi Jelili and new members are added regularly. Register for updates so we can keep you up to date on new judging appointments.</p>

							</div>
						</div>
					</div>
                    <div class="widget widget-archive">
						<h4 class="title">Joining the panel of judges</h4>
                        <p>If you would like to offer your industry knowledge and experience as a member of the Industry Judging Panel, please contact us with a summary of your experience and the category that you would like to judge. If a vacancy exists that may be suitable then we will forward your information to the Co-Chairs of Judges for a decision.</p>
                        <a class="btn btn-yellow" href="<?php echo e(route('show_contact')); ?>">Send us a message</a><br><br>
                        <p><strong>Please Note</strong><br>
                        All members of the Panel must be approved by the Co-Chairs of Judges, who consider the skills, experience and balance of the Panel as a whole. Any decision to not accept an application is therefore not a reflection on the quality of the applicant.
                        </p>
                        <p>The integrity of the Industry Judging Panel is of paramount importance and, with this in mind, all Judges are required to abide by terms and conditions covering confidentiality, conflicts of interest and the conduct expected of Judges.</p>
                    </div>
                    <div class="widget widget-archive">
						<h4 class="title">Declaration</h4>
                        <p style="color: red;">The Industry Judging Panel is independent from the production and management of the GRC & Financial Crime Prevention Awards Event. Members of the organising committee and the management company appointed to project manage the Awards Event, may not hold a position on the Industry Judging Panel.</p>
                    </div>
                </div>
                <!--================= SIDEBAR =================-->
                <?php echo $__env->make('partials.voter.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--=============== SIDEBAR END ===============-->
            </div>
        </div>
    </section>

    <?php $__currentLoopData = $judges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="j<?php echo e($judge->hashid); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header py-3 px-4 border-bottom-0">
                    <h5 class="modal-title" id="modal-title">Judge profile</h5>
                    <a class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="mdi mdi-close-circle mdi-24px" style="color: red;"></i></a>
                </div>

                <div class="modal-body px-4 pb-4 pt-0">
                    <section class="s-our-mission s-about-speaker" style="padding:0px">
                        <div class="row" style="flex-direction: column;">
                            <div class="col-lg-12 our-mission-img">
                                <span>
                                    <img class="mission-img" src="<?php echo e($judge->path_to_image); ?>" alt="img" style="width: 200px;height:200px;border-radius:50%;align-self:center">
                                </span>
                            </div>
                            <div class="col-lg-12 our-mission-info">
                                <h6><?php echo e($judge->name); ?> - <?php echo e($judge->position); ?></h6>
                                <div class="mission-info-text">
                                    <p><?php echo e($judge->profile); ?></p>
                                </div>
                                <ul class="social-list">
                                    <?php if($judge->ln_link != ''): ?>
                                    <li>
                                        <a target="_blank" href="<?php echo e($judge->ln_link); ?>">
                                            <i class="mdi mdi-linkedin mdi-24px"></i>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </section>
                    <div class="row">
                        <div class="col-6"></div>
                        <div class="col-6 text-end">
                            <button type="button" class="btn btn-success" data-bs-dismiss="modal" aria-label="Close">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!--==================== FOOTER ====================-->
    <?php echo $__env->make('partials.voter.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--================== FOOTER END ==================-->

    <!--=================== TO TOP ===================-->
    <a class="to-top" href="#home">
		<i class="mdi mdi-chevron-double-up" aria-hidden="true"></i>
	</a>
    <!--================= TO TOP END =================-->

    <!--=================== SCRIPT	===================-->
    <?php echo $__env->make('partials.voter.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <script src="<?php echo e(asset('assets/js/modal.js')); ?>"></script> -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>


</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\TMC-Projects\grcfincrimeawards\resources\views/contents/voter/meet_judges.blade.php ENDPATH**/ ?>