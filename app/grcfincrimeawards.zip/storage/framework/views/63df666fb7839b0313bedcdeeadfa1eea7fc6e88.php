<!DOCTYPE html>
<html lang="zxx">
<?php $__env->startSection('title', 'About the Award'); ?>

<head>
	<?php echo $__env->make('partials.voter.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body id="conference-page" style="background-image: url(assets/images/conference_bg.svg);">
<div class="page-preloader-cover">
		<div class="cssload-loader">
			<div class="cssload-inner" >
				<img class="ball" src="<?php echo e(asset('assets/images/grc_awards_logo.png')); ?>"/>
			</div>
		</div>
		
	</div>
	<!-- ================= HEADER ================= -->
	<?php echo $__env->make('partials.voter.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- =============== HEADER END =============== -->
	<!-- Page title -->
	<div class="page-title" style="background-color:#D4AF37">
		<div class="container">
			<div class="breadcrumbs">
				<ul>
					<li><a href="<?php echo e(route('landing.index')); ?>">Home</a></li>
					<li>Contact us</li>
				</ul>
			</div>
			<h1 class="title">Contact us</h1>
		</div>
	</div>
	<!-- page title -->

	<section class="s-news s-single-news" style="background-color: #fff;">
		<div class="container">
			<div class="row">
				<div class="col-12 col-lg-8 blog-cover">
					<div class="marathon-register-row" style="justify-content: center;">
						<div class="marathon-register">
						<h2 class="title"><span>Send us a Message</span></h2>
							<form id='regForm' method="POST" action="">
								<?php echo csrf_field(); ?>
								<ul class="form-cover">
									<li class="inp-cover">
										<input id="first_name" type="text" name="first_name" placeholder="First name" required>
									</li>
									<li class="inp-cover">
										<input id="last_name" type="text" name="last_name" placeholder="Last name" required>
									</li>
									<li class="inp-cover inp-email">
										<input id="email" type="email" name="email" placeholder="E-mail" required>
										
									</li>
									<li class="inp-text"><textarea id="comments" name="message" placeholder="Message"></textarea></li>
								</ul>
								<div class="btn-form-cover">
									<button id="#submit" type="submit" class="btn">
										<span>Submit</span>
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<!--================= SIDEBAR =================-->
				<?php echo $__env->make('partials.voter.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!--=============== SIDEBAR END ===============-->
			</div>
		</div>
	</section>

	<!--==================== FOOTER ====================-->
	<?php echo $__env->make('partials.voter.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--================== FOOTER END ==================-->

	<!--=================== TO TOP ===================-->
	<a class="to-top" href="#home">
		<i class="mdi mdi-chevron-double-up" aria-hidden="true"></i>
	</a>
	<!--================= TO TOP END =================-->

	<!--=================== SCRIPT	===================-->
	<?php echo $__env->make('partials.voter.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/contents/voter/contact.blade.php ENDPATH**/ ?>