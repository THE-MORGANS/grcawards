

<?php $__env->startSection('title', 'Sectors & Awards'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box" style="margin-top: 20px; margin-bottom: 20px;">

                <div class="page-title">
                    <div style="width: 55px;float: left;height: 55px;background: turquoise;margin-right: 15px;">
                    </div>
                    <h4 style="display: block;">Award Year 2021</h4>
                    <h4 style="display: block;" class=" text-muted fw-normal mt-0 mb-0">sdfondsfjvnfv
                    </h4>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                <h4 class="header-title mb-3"><?php echo e($category->name); ?></h4>
                <p><?php echo e($category->description); ?></p>
                    <!-- Checkout Steps -->
                    <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                        <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <li class="nav-item">
                            <a href="#sector<?php echo e($sector->hashid); ?>" data-bs-toggle="tab" aria-expanded="<?php echo e($loop->iteration==1?'true':'false'); ?>" class="nav-link rounded-0 <?php echo e($loop->iteration==1?'active':''); ?>">
                                <i class="mdi mdi-account-circle font-18"></i>
                                <span class="d-none d-lg-block"><?php echo e($sector->name); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- Steps Information -->
                    <div class="tab-content">
                        <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane show active" id="sector<?php echo e($sector->hashid); ?>">
                            <div class="row">
                                <?php $__currentLoopData = $sector->awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6">
                                    <div class="border p-3 mt-4 mt-lg-0 rounded">
                                        <h4 class="header-title mb-3"><?php echo e($award->name); ?></h4>
                                        <p><?php echo e($award->description); ?></p>
                                        <p><?php echo e($award->criteria); ?></p>
                                        <div class="table-responsive">
                                            <table class="table table-centered mb-0">
                                                <tbody>
                                                    
                                                    <tr>
                                                        <td>
                                                            <p class="m-0 d-inline-block align-middle">
                                                                <a href="apps-ecommerce-products-details.html" class="text-body fw-semibold">Amazing Modern Chair</a>
                                                                <span class="badge badge-outline-success ms-1" style="padding:3px; font-size:14px;">43 Votes</span>
                                                            </p>
                                                        </td>
                                                        <td class="text-end">
                                                        <a href="javascript:void(0);" data-bs-container="#tooltip-container9" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download" class="btn btn-link text-muted btn-lg p-0">
                                                                    <i class="uil uil-cloud-download"></i>
                                                                </a>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <p class="m-0 d-inline-block align-middle">
                                                                <a href="apps-ecommerce-products-details.html" class="text-body fw-semibold">Designer Awesome Chair</a>
                                                                <br>
                                                                <small>2 x $99.00</small>
                                                            </p>
                                                        </td>
                                                        <td class="text-end">
                                                            $198.00
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <p class="m-0 d-inline-block align-middle">
                                                                <a href="apps-ecommerce-products-details.html" class="text-body fw-semibold">Biblio Plastic Armchair</a>
                                                                <br>
                                                                <small>1 x $129.99</small>
                                                            </p>
                                                        </td>
                                                        <td class="text-end">
                                                            $129.99
                                                        </td>
                                                    </tr>
                                                    <tr class="text-end">
                                                        <td>
                                                            <h6 class="m-0">Sub Total:</h6>
                                                        </td>
                                                        <td class="text-end">
                                                            $1071.29
                                                        </td>
                                                    </tr>
                                                    <tr class="text-end">
                                                        <td>
                                                            <h6 class="m-0">Shipping:</h6>
                                                        </td>
                                                        <td class="text-end">
                                                            FREE
                                                        </td>
                                                    </tr>
                                                    <tr class="text-end">
                                                        <td>
                                                            <h5 class="m-0">Total:</h5>
                                                        </td>
                                                        <td class="text-end fw-semibold">
                                                            $1071.29
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <!-- end table-responsive -->
                                    </div> <!-- end .border-->

                                </div> <!-- end col -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div> <!-- end row-->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- End Billing Information Content-->
                    </div> <!-- end tab content-->
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/contents/admin/sectors_awards.blade.php ENDPATH**/ ?>