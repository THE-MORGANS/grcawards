<!DOCTYPE html>
<html lang="en">
<?php $__env->startSection('title', 'Pictures'); ?>

<head>
    <?php echo $__env->make('partials.voter.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="<?php echo e(asset('assets/css/model-new.css')); ?>" rel="stylesheet" />
</head>

<body id="conference-page">
    <!-- =============== PRELOADER =============== -->
    <!-- <div class="page-preloader-cover">
        <div class="cssload-loader">
            <div class="cssload-inner">
                <img class="ball" src="<?php echo e(asset('assets/images/grc_awards_logo.png')); ?>" />
            </div>
        </div>

    </div> -->
    <!-- ============== PRELOADER END ============== -->
    <!-- ================= HEADER ================= -->
    <?php echo $__env->make('partials.voter.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =============== HEADER END =============== -->
    <!-- Page title -->
    <div class="page-title" style="background-color:#D4AF37">
        <div class="container">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?php echo e(route('landing.index')); ?>">Home</a></li>
                    <li>Media</li>
                </ul>
            </div>
            <h3 class="title">Media</h3>
        </div>
    </div>
    <!-- page title -->

    <section class="s-news s-single-news" style="background-color: #fff;">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8 blog-cover">
                    <div class="post-item-cover">
                        <div class="widget widget-archive post-header">
                            <h4 class="title">Picture Gallery</h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <div class="post-item-cover wow fadeInUp" data-wow-duration=".35s" data-wow-delay=".4s">
                                <div class="post-header">
                                    <h6 class="title">
                                        <a href="<?php echo e(route('show_pictures')); ?>">2021</a>
                                    </h6>
                                    <div class="post-thumbnail">
                                        <a href="<?php echo e(route('show_pictures', [award_program => 1])); ?>">
                                            <img src="<?php echo e(asset('uploads/DP0J1703.JPG')); ?>" alt="img">
                                        </a>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--================= SIDEBAR =================-->
                <?php echo $__env->make('partials.voter.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--=============== SIDEBAR END ===============-->
            </div>
        </div>
    </section>

    <!--==================== FOOTER ====================-->
    <?php echo $__env->make('partials.voter.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--================== FOOTER END ==================-->

    <!--=================== TO TOP ===================-->
    <a class="to-top" href="#home">
		<i class="mdi mdi-chevron-double-up" aria-hidden="true"></i>
	</a>
    <!--================= TO TOP END =================-->

    <!--=================== SCRIPT	===================-->
    <?php echo $__env->make('partials.voter.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <script src="<?php echo e(asset('assets/js/modal.js')); ?>"></script> -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>


</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/contents/voter/pictures_categories.blade.php ENDPATH**/ ?>