<script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/partials/admin/scripts.blade.php ENDPATH**/ ?>