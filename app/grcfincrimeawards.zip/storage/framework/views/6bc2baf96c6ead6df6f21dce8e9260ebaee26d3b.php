<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('partials.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="loading"
    data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
    <!-- Global page wrapper-->
    <div class="wrapper">
        <!-- Left Sidebar Start -->
        <?php echo $__env->make('partials.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Left Sidebar End -->

        <!-- Page content wrapper -->
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php echo $__env->make('partials.admin.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- end Topbar -->

                <!-- Start Content-->
                <?php echo $__env->yieldContent('content'); ?>
                <!-- container -->
            </div>
            <!-- Footer Start -->
            <?php echo $__env->make('partials.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Footer -->
        </div>
        <!-- End Page content -->
    </div>
    <!-- END wrapper -->

    <!-- scripts -->
    <?php echo $__env->make('partials.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('scripts'); ?>
    
</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/layouts/admin/master.blade.php ENDPATH**/ ?>