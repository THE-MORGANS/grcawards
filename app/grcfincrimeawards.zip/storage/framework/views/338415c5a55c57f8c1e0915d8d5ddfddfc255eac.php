<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"> -->

    <style>
        .dropdown-menu-animated.show {
            top: 70% !important;
        }

        .dropdown-menu {
            min-width: 0;
        }
    </style>
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
    <!-- Begin page -->
    <div class="wrapper">
        <!-- Start Page Content here -->
        <div class="content-page" style="margin-left:0;">
            <div class="leftside-menu" style="left:0; bottom: auto;">

                <!-- LOGO -->
                <a href="index.html" class="logo text-center logo-light">
                    <span class="logo-lg">
                        <img src="assets/images/logo.png" alt="" height="16">
                    </span>
                    <span class="logo-sm">
                        <img src="assets/images/logo_sm.png" alt="" height="16">
                    </span>
                </a>
            </div>
            <div class="content container">
                <!-- Topbar Start -->
                <?php echo $__env->make('partials.admin.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- end Topbar -->

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box" style="margin-top: 20px; margin-bottom: 20px;">

                                <div class="page-title">
                                    <div style="width: 55px;float: left;height: 55px;background: turquoise;margin-right: 15px;">
                                    </div>
                                    <h4 style="display: block;">Award Year 2021</h4>
                                    <h4 style="display: block;" class=" text-muted fw-normal mt-0 mb-0">sdfondsfjvnfv
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <div class="row mb-2">
                        <div class="col-sm-8">
                            <a href="<?php echo e(route('award.program.create')); ?>" data-action="create" class="btn btn-success mb-2" style="margin-right: .75rem;" data-bs-toggle="modal" data-bs-target="#award-modal">
                                <i class="mdi mdi-plus-thick me-1"></i>
                                Create Award Year
                            </a>
                            <a href="" class="btn btn-secondary mb-2" style="margin-right: .75rem;">
                                <i class="mdi mdi-close-thick me-1"></i>
                                Delete
                            </a>
                        </div>
                    </div>
                    <?php if($awps->isEmpty()): ?>
                    <div class="row justify-content-center">
                        <div class="col-lg-4">
                            <div class="text-center">
                                <img src="<?php echo e(asset('assets/images/no-result.svg')); ?>" height="300" alt="no-result-found-image">
                                <!-- <h1 class="text-error mt-4">404</h1> -->
                                <h3 class="text-uppercase text-primary mt-4">No results found</h3>
                            </div> <!-- end /.text-center-->
                        </div> <!-- end col-->
                    </div>
                    <?php else: ?>
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive-sm">
                                    <table class="table table-hover table-sm table-centered mb-0">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input" id="customCheck1">
                                                    </div>
                                                </th>
                                                <th>AWard Name</th>
                                                <th>Award Year</th>
                                                <th>Created on</th>
                                                <th>Created by</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $awps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $awp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="form-check">
                                                        <input type="checkbox" class="form-check-input" id="customCheck2">
                                                    </div>
                                                </td>
                                                <td><a href="<?php echo e(route('award.program', $awp->hashid)); ?>"><?php echo e($awp->name); ?></a></td>
                                                <td><?php echo e($awp->year); ?></td>
                                                <td><?php echo e($awp->created_at); ?></td>
                                                <td><?php echo e($awp->admin->fullname); ?></td>
                                                <td><span class="badge <?php echo e($awp->status == 1 ? 'badge-success-lighten' : 'badge-danger-lighten'); ?>"><?php echo e($awp->status == 1 ? 'Active' : 'Inactive'); ?></span></td>
                                                <td class="table-action dropdown">
                                                    <a href="#" class="action-icon dropdown-toggle arrow-none" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="mdi mdi-dots-vertical"></i></a>
                                                    <div class="dropdown-menu dropdown-menu-animated">
                                                        <a class="dropdown-item" href="<?php echo e($awp->status == 1 ? route('award.program.deactivate', $awp->hashid) : route('award.program.activate', $awp->hashid)); ?>"><?php echo e($awp->status == 1 ? 'Deactivate' : 'Activate'); ?></a>
                                                        <a class="dropdown-item" data-action="edit" data-id="<?php echo e($awp->hashid); ?>" data-year="<?php echo e($awp->year); ?>" data-name="<?php echo e($awp->name); ?>" data-loc="<?php echo e($awp->location); ?>" href="<?php echo e(route('award.program.update',$awp->hashid)); ?>" data-bs-toggle="modal" data-bs-target="#award-modal">Edit</a>
                                                        <a class="dropdown-item" href="<?php echo e(route('award.program.delete',$awp->hashid)); ?>">Delete</a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div> <!-- end table-responsive-->
                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div>
                    <?php endif; ?>
                </div>
                <!-- container -->
                <!-- Add New Event MODAL -->
                <div class="modal fade" id="award-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="" class="needs-validation" name="award-form" id="form-award">
                                <?php echo csrf_field(); ?>
                                <div class="modal-header py-3 px-4 border-bottom-0">
                                    <h5 class="modal-title" id="modal-title"></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body px-4 pb-4 pt-0">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="control-label form-label">Program Name</label>
                                                <input class="form-control <?php $__errorArgs = ['award_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. GRCFinCrimeAwardsNigeria" type="text" name="award_name" id="award_name" value required autocomplete="off" />
                                                <?php $__errorArgs = ['award_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="control-label form-label">Program Year</label>
                                                <select class="form-select <?php $__errorArgs = ['award_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="award_year" id="award_year" required>
                                                    <option id="init" value="#">Please select...</option>
                                                </select>
                                                <?php $__errorArgs = ['award_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong> select a valid event category</strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="control-label form-label">Program Location</label>
                                                <input class="form-control <?php $__errorArgs = ['award_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="e.g. Nigeria" type="text" name="award_location" id="award_location" required autocomplete="off" />
                                                <?php $__errorArgs = ['award_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6"></div>
                                        <div class="col-6 text-end">
                                            <button type="button" class="btn btn-light me-1" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-success" id="btn-save"></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div> <!-- end modal-content-->
                    </div> <!-- end modal dialog-->
                </div>
                <!-- end modal-->                
            </div>
            <!-- content -->

            <!-- Footer Start -->
            <?php echo $__env->make('partials.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Footer -->

        </div>
        <!-- End Page content -->
    </div>
    <!-- END wrapper -->

    <!-- scripts -->
    <?php echo $__env->make('partials.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('assets/js/pages/index-page.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <?php if(Session::has('success')): ?>
    <script>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.success("<?php echo e(session('success')); ?>");
    </script>
    <?php endif; ?>

    <?php if(Session::has('danger')): ?>
    <script>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.error("<?php echo e(session('danger')); ?>");
    </script>
    <?php endif; ?>

</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/contents/admin/index.blade.php ENDPATH**/ ?>