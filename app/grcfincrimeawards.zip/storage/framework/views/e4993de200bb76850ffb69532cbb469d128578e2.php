<meta charset="utf-8" />
<title><?php echo $__env->yieldContent('title'); ?> | GRCFinCrimeAwards</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta content="Dedicated to celebrating businesses thriving in Governance, Risk Management & Compliance and Financial Crime Prevention" name="description" />
<meta name="keywords" content="">
<meta content="GRC Awards" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
<!-- =================== STYLE =================== -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/slick.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-grid.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<?php echo $__env->yieldContent('style'); ?><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/partials/voter/head.blade.php ENDPATH**/ ?>