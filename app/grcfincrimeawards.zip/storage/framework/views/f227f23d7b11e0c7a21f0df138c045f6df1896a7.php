<!DOCTYPE html>
<html lang="zxx">
<?php $__env->startSection('title', 'Shortlisted Nominees'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/accordion.css')); ?>">
<?php $__env->stopSection(); ?>

<head>
    <?php echo $__env->make('partials.voter.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body id="conference-page" style="background-image: url(assets/images/conference_bg.svg);">
    <!-- =============== PRELOADER =============== -->
    <div class="page-preloader-cover">
		<div class="cssload-loader">
			<div class="cssload-inner" >
				<img class="ball" src="<?php echo e(asset('assets/images/grc_awards_logo.png')); ?>"/>
			</div>
		</div>
		
	</div>
    <!-- ============== PRELOADER END ============== -->
    <!-- ================= HEADER ================= -->
    <?php echo $__env->make('partials.voter.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =============== HEADER END =============== -->
    <!-- Page title -->
    <div class="page-title" style="background-color:#D4AF37">
        <div class="container">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?php echo e(route('landing.index')); ?>">Home</a></li>
                    <li>Shortlisted Nominees</li>
                </ul>
            </div>
            <h1 class="title">Shortlisted Nominees</h1>
        </div>
    </div>
    <!-- page title -->

    <section class="s-news s-single-news" style="background-color: #fff;">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8 blog-cover">
                    <div class="post-item-cover">
                        <div class="widget widget-archive post-header">
                            <h4 class="title">2021 Shortlisted Nominees</h4>
                        </div>
                        <!-- <div class="post-content">
                            <div class="text">
                                <p>The GRC & FinCrime Prevention Awards will be presented to several sectors that employ/incorporate Governance, Risk management, Compliance and Financial Crime Prevention mechanisms in their business activities.</p>
                                <p>The GRC & FinCrime Prevention Awards comprises of six categories of awards with various subcategories.</p>
                            </div>
                        </div> -->
                    </div>
                    <div class="accordion-wrapper" style="margin-top: 30px;">
                          
                        <div class="accordion">
                            <input class="in-check" type="checkbox" name="radio-a" id="aaa"/>
                            <label class="accordion-label" for="aaa">GRC fincrime (Commercial bank)</label>
                            <div class="accordion-content">
                            <!-- <p></p> -->
                                <div class="row">
                                    
                                    <div class="col-md-12" style="margin-bottom:30px">
                                        <div class="buy-ticket-left">
                                            <!-- <div class="ticket-contact-cover" style="padding-top:10px;"> -->
                                                <div class="ticket-contact-item">
                                                    <div class="pay-method row" style="overflow-wrap: break-word;">
                                                        <!-- <div class="pay-item" style="flex-direction:row;justify-content:flex-start;"> -->
                                                            <div class="col-6">
                                                                <p>GRC Employer of the Year</p>
                                                            </div>
                                                            <div class="col-6">
                                                               <ul>
                                                                   <li>Access Bank</li>
                                                                   <li>GTBank</li>
                                                               </ul>
                                                            </div>
                                                        <!-- </div> -->
                                                    </div>    
                                                </div>
                                            <!-- </div> -->
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <!--================= SIDEBAR =================-->
                <?php echo $__env->make('partials.voter.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--=============== SIDEBAR END ===============-->
            </div>
        </div>
    </section>

    <!--==================== FOOTER ====================-->
    <?php echo $__env->make('partials.voter.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--================== FOOTER END ==================-->

    <!--=================== TO TOP ===================-->
    <a class="to-top" href="#home">
		<i class="mdi mdi-chevron-double-up" aria-hidden="true"></i>
	</a>
    <!--================= TO TOP END =================-->

    <!--=================== SCRIPT	===================-->
    <?php echo $__env->make('partials.voter.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/contents/voter/shortlisted_nominees.blade.php ENDPATH**/ ?>