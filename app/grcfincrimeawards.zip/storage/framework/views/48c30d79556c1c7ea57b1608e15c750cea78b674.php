<script src="<?php echo e(asset('assets/js/jquery-2.2.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/rx-lazy.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/partials/voter/scripts.blade.php ENDPATH**/ ?>