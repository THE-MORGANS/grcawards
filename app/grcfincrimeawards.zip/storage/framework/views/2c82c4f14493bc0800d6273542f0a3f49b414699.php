<!DOCTYPE html>
<html lang="zxx">
<?php $__env->startSection('title', 'Vote'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/accordion.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php $__env->stopSection(); ?>

<head>
    <?php echo $__env->make('partials.voter.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body id="conference-page">
    <!-- =============== PRELOADER =============== -->
    <div class="page-preloader-cover">
        <div class="cssload-loader">
            <div class="cssload-inner">
                <img class="ball" src="<?php echo e(asset('assets/images/grc_awards_logo.png')); ?>" />
            </div>
        </div>

    </div>
    <!-- ============== PRELOADER END ============== -->
    <!-- ================= HEADER ================= -->
    <?php echo $__env->make('partials.voter.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =============== HEADER END =============== -->
    <!-- Page title -->
    <div class="page-title" style="background-color:#D4AF37">
        <div class="container">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?php echo e(route('landing.index')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('show_vote')); ?>">Categories</a></li>
                    <li>Awards</li>
                </ul>
            </div>
            <h1 class="title">Awards</h1>
        </div>
    </div>
    <!-- page title -->

    <section class="s-news s-single-news" style="background-color: #fff;">
        <div class="container">
            <div class="row">
                <div class="col-12 blog-cover">
                    <div class="post-item-cover">
                        <div class="widget widget-archive post-header">
                            <h4 class="title"><?php echo e($sector->category->name); ?> (<?php echo e($sector->name); ?>)</h4>
                        </div>
                        <div class="post-content">
                            <div class="text">
                                <p><?php echo e($sector->category->description); ?></p>
                                <p><strong>NOTE: </strong> You have only one vote under each sub-category</p>
                            </div>
                        </div>
                    </div>
                </div>

                <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="accordion-wrapper" style="margin-top: 30px;">
                        <div class="accordion">
                            <input class="in-check" type="checkbox" name="radio-a" id="<?php echo e($award->hashid); ?>1">
                            <label class="accordion-label" for="<?php echo e($award->hashid); ?>1"><?php echo e($award->name); ?></label>
                            <div class="accordion-content">
                                <p> <?php echo e($award->id == 33 || $award->id == 34 || $award->id == 39 ? '' : $award->description); ?></p>
                                <h6>Award Criteria</h6>
                                <p><?php echo e($award->criteria); ?></p>
                                <form action="<?php echo e(route('landing.index')); ?>" id="<?php echo e($award->hashid); ?>2">
                                    <div class="buy-ticket-left">
                                        <p><?php echo e($award->id ==33 || $award->id ==34 ? '' : 'The following are the nominees for this Award sub-category.'); ?></p>
                                        <p><strong>Please place your vote by <?php echo e($award->id ==33 || $award->id ==34 ? 'stating the name of your nominee and clicking the "Vote" button' : 'selecting a nominee and clicking the "Vote" button after the list'); ?>.</strong></p>
                                        <div class="ticket-contact-item" style="margin-right:0px">
                                            <div class="buy-ticket-form">
                                                <?php echo csrf_field(); ?>
                                                <?php if($award->id == 33 || $award->id ==34): ?>
                                                <div class="pay-method">
                                                    <ul class="form-cover" style="justify-content: flex-start;flex-direction:column;">
                                                        <li class="inp-email footer-subscribe">
                                                            <input id="nominee" type="text" name="<?php echo e($award->hashid); ?>" style="width:100%" placeholder="Enter your Nominee" required>
                                                            <?php $__errorArgs = ['token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert" style="color:red">
                                                                <?php echo e($message); ?>

                                                            </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <?php else: ?>
                                                <div class="pay-method">
                                                    <?php $__currentLoopData = $nominees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nominee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(in_array($award->id, json_decode($nominee->award_ids))): ?>
                                                    <div class="pay-item">
                                                        <input type="radio" name="<?php echo e($award->hashid); ?>" data-id="<?php echo e($nominee->hashid); ?>" value="<?php echo e($nominee->hashid); ?>">
                                                        <span></span>
                                                        <p class="nominee"><?php echo e($nominee->name); ?></p>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                    <?php endif; ?>
                                            </div>
                                        </div>
                                        <div style="text-align:center">
                                            <button id="<?php echo e($award->id == 33 || $award->id ==34 ? '#SubmitNominee' : '#Submit'); ?>" type="submit" data-id="<?php echo e($award->hashid); ?>" class="btn"><span>Vote</span></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 blog-cover" style="margin-top:100px">
                    <div class="post-item-cover">
                        <div class="widget widget-archive post-header">
                            <h4 class="title" style="color:red">Declaration</h4>
                        </div>
                        <div class="post-content">
                            <div class="text">
                                <p>We recognize that conflicts of interest can be a severe problem and we take them extremely seriously. We do everything we can to keep conflicts to a minimum while recognizing and rewarding the best. The organizers, partners/sponsors, and representatives of the GRC & Financial Crime Awards have no influence over the online vote in any form.
                                    Individuals and Organizations are recognized for their Governance, Risks management & Compliance and Financial Crime achievements, beneficial contributions to their sectors and the Nigerian economy at large.</p>
                            </div>
                        </div>
                    </div>
                    <div class="post-item-cover">
                        <div class="widget widget-archive post-header">
                            <h4 class="title" style="color:red">Security Warning!!!</h4>
                        </div>
                        <div class="post-content">
                            <div class="text">
                                <p>As stated, voting is open to the public. Every voter is entitled to <strong>only one vote </strong> on each Award Sub-category.</p>
                                <p>As such, <span style="color:red">The use of devices/softwares such as VPNs, software generated or programmed scripts </span> to manipulate votes is prohibited. However, we have employed the use of advance technologies to counter this situation and make sure votes are secure and counted correctly. </p>
                                <p>GRC & Financial Crime Awards reserves the exclusive right to disqualify any Individual(s) or Organization(s) if they are in violation of the voting rules.</p>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </section>

    <!--==================== FOOTER ====================-->
    <?php echo $__env->make('partials.voter.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--================== FOOTER END ==================-->

    <!--=================== TO TOP ===================-->
    <a class="to-top" href="#home">
        <i class="mdi mdi-chevron-double-up" aria-hidden="true"></i>
    </a>
    <!--================= TO TOP END =================-->

    <!--=================== SCRIPT	===================-->
    <?php echo $__env->make('partials.voter.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="<?php echo e(asset('assets/js/scripter.js')); ?>"></script>
</body>

</html><?php /**PATH C:\wamp64\www\laravel-projects\grcfincrimeawards\resources\views/contents/voter/awards.blade.php ENDPATH**/ ?>